package dev.hytalemodding.commands;

import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.math.vector.Vector3d;
import com.hypixel.hytale.math.vector.Vector3f;
import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.command.system.basecommands.AbstractPlayerCommand;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import com.hypixel.hytale.server.core.universe.world.World;
import com.hypixel.hytale.server.core.universe.world.npc.INonPlayerCharacter;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import com.hypixel.hytale.server.npc.NPCPlugin;
import it.unimi.dsi.fastutil.Pair;
import org.checkerframework.checker.nullness.compatqual.NonNullDecl;

public class TurretSpawnCommand extends AbstractPlayerCommand {

    private static final String TURRET_NPC_ID = "Turret";

    public TurretSpawnCommand() { super("tesla_turret", "spawn turret npc");
    }

    @Override
    protected void execute(@NonNullDecl CommandContext ctx,
                           @NonNullDecl Store<EntityStore> store,
                           @NonNullDecl Ref<EntityStore> ref,
                           @NonNullDecl PlayerRef playerRef,
                           @NonNullDecl World world) {

        try {
            // Get the player's current position to spawn the NPC at the same location
            Vector3d position = playerRef.getTransform().getPosition();

            // Define the initial rotation (facing direction) for the NPC
            Vector3f rotation = new Vector3f(0, playerRef.getTransform().getRotation().y, 0);

            Pair<Ref<EntityStore>, INonPlayerCharacter> result = NPCPlugin.get().spawnNPC(store, TURRET_NPC_ID, null, position, rotation);

            if (result != null) {
                // Successfully spawned
                ctx.sender().sendMessage(Message.raw("Turret gespawnt: " + TURRET_NPC_ID));
            } else {
                ctx.sender().sendMessage(Message.raw("spawnNPC returned null (Role-Key '" + TURRET_NPC_ID + "' nicht gefunden/geladen?)"));
            }
        } catch (Throwable t) {
            ctx.sender().sendMessage(Message.raw("Spawn failed: " + t.getClass().getSimpleName() + " - " + t.getMessage()));
        }
    }
}
