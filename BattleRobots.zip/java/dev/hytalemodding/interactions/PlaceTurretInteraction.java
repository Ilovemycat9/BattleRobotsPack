package dev.hytalemodding.interactions;

import com.hypixel.hytale.codec.builder.BuilderCodec;
import com.hypixel.hytale.component.CommandBuffer;
import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.math.vector.Vector3d;
import com.hypixel.hytale.math.vector.Vector3f;
import com.hypixel.hytale.protocol.InteractionState;
import com.hypixel.hytale.protocol.InteractionType;
import com.hypixel.hytale.server.core.entity.InteractionContext;
import com.hypixel.hytale.server.core.modules.entity.component.TransformComponent;
import com.hypixel.hytale.server.core.modules.interaction.interaction.CooldownHandler;
import com.hypixel.hytale.server.core.modules.interaction.interaction.config.SimpleInstantInteraction;
import com.hypixel.hytale.server.core.universe.world.World;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import com.hypixel.hytale.server.npc.NPCPlugin;

import javax.annotation.Nonnull;

public class PlaceTurretInteraction extends SimpleInstantInteraction {
    public static final BuilderCodec<PlaceTurretInteraction> CODEC = BuilderCodec.builder(
            PlaceTurretInteraction.class, PlaceTurretInteraction::new, SimpleInstantInteraction.CODEC
    ).build();

    @Override
    protected void firstRun(@Nonnull InteractionType interactionType,
                            @Nonnull InteractionContext ctx,
                            @Nonnull CooldownHandler cooldownHandler) {

        try {
            var heldItem = ctx.getHeldItem();

            if (heldItem == null || heldItem.isEmpty() ) {
                ctx.getState().state = InteractionState.Failed;
                return;
            }

            String itemId = heldItem.getItemId();

            String roleKey = switch (itemId) {
                case "Tesla_Turret" -> "TeslaTurret";
                case "Turret"      -> "Turret";
                default            -> "TeslaTurret";
            };

            CommandBuffer<EntityStore> commandBuffer = ctx.getCommandBuffer();
            if (commandBuffer == null) {
                ctx.getState().state = InteractionState.Failed;
                return;
            }

            Ref<EntityStore> ref = ctx.getEntity();

            TransformComponent transform = commandBuffer.getComponent(ref, TransformComponent.getComponentType());
            if (transform == null) {
                ctx.getState().state = InteractionState.Failed;
                return;
            }

            var p = transform.getPosition();
            var r = transform.getRotation();
            Vector3d pos = new Vector3d(p.x, p.y, p.z);
            Vector3f rotation = new Vector3f(r.x, r.y, r.z);

            World world = commandBuffer.getExternalData().getWorld();

            world.execute(() -> {
                Store<EntityStore> store = world.getEntityStore().getStore();
                var result = NPCPlugin.get().spawnNPC(store, roleKey, null, pos, rotation);
                if (result == null) {
                    System.out.println("[TurretMod] spawnNPC returned null");
                }
            });

            ctx.getState().state = InteractionState.Finished;
            System.out.println("[TurretMod] Spawned turret via item interaction");
        } catch (Throwable t) {
            t.printStackTrace();
            ctx.getState().state = InteractionState.Failed;
        }
    }
}

