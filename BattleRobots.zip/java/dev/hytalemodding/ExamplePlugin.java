package dev.hytalemodding;

import com.hypixel.hytale.server.core.event.events.player.PlayerReadyEvent;
import com.hypixel.hytale.server.core.plugin.JavaPlugin;
import com.hypixel.hytale.server.core.plugin.JavaPluginInit;
import dev.hytalemodding.commands.TurretSpawnCommand;
import dev.hytalemodding.events.ExampleEvent;
import dev.hytalemodding.interactions.PlaceTurretInteraction;
import com.hypixel.hytale.server.core.modules.interaction.interaction.config.Interaction;

import javax.annotation.Nonnull;

public class ExamplePlugin extends JavaPlugin {

    public ExamplePlugin(@Nonnull JavaPluginInit init) {

        super(init);
    }

    @Override
    protected void setup() {
        this.getCodecRegistry(Interaction.CODEC).register("turret_interaction_id", PlaceTurretInteraction.class, PlaceTurretInteraction.CODEC);
        this.getCommandRegistry().registerCommand(new TurretSpawnCommand());
        this.getEventRegistry().registerGlobal(PlayerReadyEvent.class, ExampleEvent::onPlayerReady);
    }
}